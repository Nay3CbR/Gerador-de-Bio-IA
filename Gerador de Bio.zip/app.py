from flask import Flask, request, jsonify
from flask_cors import CORS
from transformers import pipeline
import logging

app = Flask(__name__)
CORS(app)

# Configurar log
logging.basicConfig(filename='bios.log', level=logging.INFO)

# Carregar o modelo GPT-2 localmente
generator = pipeline('text-generation', model='distilgpt2')  # Usando distilgpt2 pra ser mais leve

@app.route('/generate-bio', methods=['POST'])
def generate_bio():
    data = request.json
    name = data.get('name')
    interests = data.get('interests')
    extra = data.get('extra', '')
    emojis = data.get('emojis', '')
    vibe = data.get('vibe')
    tone = data.get('tone')

    prompt = f"""
    Crie uma bio de Instagram para {name}, que gosta de {interests}, com uma vibe {vibe} e tom {tone}.
    Inclua emojis ({emojis if emojis else 'use emojis criativos'}) e, se fornecido, use '{extra}' de forma criativa.
    Máximo 100 caracteres.
    """

    try:
        response = generator(prompt, max_length=100, num_return_sequences=1, temperature=0.9)
        bio = response[0]['generated_text'].split('\n')[0][:100]
        # Log da bio gerada
        logging.info(f"Bio gerada: {bio} | Input: {data}")
    except Exception as e:
        bio = f'Erro ao gerar bio: {str(e)}'
        logging.error(f"Erro: {str(e)}")

    return jsonify({'bio': bio})

if __name__ == '__main__':
    app.run(port=5000)